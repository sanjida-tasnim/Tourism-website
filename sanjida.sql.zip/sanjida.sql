-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 29, 2019 at 06:52 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sanjida`
--

-- --------------------------------------------------------

--
-- Table structure for table `beaches`
--

CREATE TABLE `beaches` (
  `beach no` int(255) NOT NULL,
  `Beach name` varchar(255) NOT NULL,
  `budget` int(255) NOT NULL,
  `transportation way` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `beaches`
--

INSERT INTO `beaches` (`beach no`, `Beach name`, `budget`, `transportation way`) VALUES
(1, 'coxs bazar', 10000, 'bus');

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `client no` int(255) NOT NULL,
  `client name` varchar(255) NOT NULL,
  `phone number` int(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`client no`, `client name`, `phone number`, `address`, `city`) VALUES
(1, 'sanjida', 1632478961, '16/9modhubag', 'dhaka');

-- --------------------------------------------------------

--
-- Table structure for table `hill station`
--

CREATE TABLE `hill station` (
  `Hill station no` int(255) NOT NULL,
  `location name` varchar(255) NOT NULL,
  `budget` int(255) NOT NULL,
  `transportation way` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `islands`
--

CREATE TABLE `islands` (
  `island no` int(255) NOT NULL,
  `location name` varchar(255) NOT NULL,
  `budget` int(255) NOT NULL,
  `transportation way` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `placestovisit`
--

CREATE TABLE `placestovisit` (
  `place id` int(255) NOT NULL,
  `place name` varchar(255) NOT NULL,
  `budget` int(255) NOT NULL,
  `transportation way` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `service no` int(255) NOT NULL,
  `Beach no` int(255) NOT NULL,
  `Hill station no` int(255) NOT NULL,
  `island no` int(255) NOT NULL,
  `waterfall no` int(255) NOT NULL,
  `client id` int(255) NOT NULL,
  `place id` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `waterfalls`
--

CREATE TABLE `waterfalls` (
  `waterfall no` int(255) NOT NULL,
  `location name` varchar(255) NOT NULL,
  `budget` int(255) NOT NULL,
  `transportation way` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `beaches`
--
ALTER TABLE `beaches`
  ADD PRIMARY KEY (`beach no`);

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`client no`);

--
-- Indexes for table `hill station`
--
ALTER TABLE `hill station`
  ADD PRIMARY KEY (`Hill station no`);

--
-- Indexes for table `islands`
--
ALTER TABLE `islands`
  ADD PRIMARY KEY (`island no`);

--
-- Indexes for table `placestovisit`
--
ALTER TABLE `placestovisit`
  ADD PRIMARY KEY (`place id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`service no`),
  ADD KEY `Beach no` (`Beach no`),
  ADD KEY `Hill station no` (`Hill station no`),
  ADD KEY `island no` (`island no`),
  ADD KEY `waterfall no` (`waterfall no`),
  ADD KEY `client id` (`client id`),
  ADD KEY `place id` (`place id`);

--
-- Indexes for table `waterfalls`
--
ALTER TABLE `waterfalls`
  ADD PRIMARY KEY (`waterfall no`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `services`
--
ALTER TABLE `services`
  ADD CONSTRAINT `services_ibfk_1` FOREIGN KEY (`place id`) REFERENCES `placestovisit` (`place id`),
  ADD CONSTRAINT `services_ibfk_2` FOREIGN KEY (`Beach no`) REFERENCES `beaches` (`beach no`),
  ADD CONSTRAINT `services_ibfk_3` FOREIGN KEY (`Hill station no`) REFERENCES `hill station` (`Hill station no`),
  ADD CONSTRAINT `services_ibfk_4` FOREIGN KEY (`island no`) REFERENCES `islands` (`island no`),
  ADD CONSTRAINT `services_ibfk_5` FOREIGN KEY (`waterfall no`) REFERENCES `waterfalls` (`waterfall no`),
  ADD CONSTRAINT `services_ibfk_6` FOREIGN KEY (`client id`) REFERENCES `client` (`client no`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
